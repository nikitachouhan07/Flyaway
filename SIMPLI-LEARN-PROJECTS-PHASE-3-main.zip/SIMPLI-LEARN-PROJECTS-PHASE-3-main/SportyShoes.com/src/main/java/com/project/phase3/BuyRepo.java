package com.project.phase3;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BuyRepo extends JpaRepository<Buy, Integer>{

}
